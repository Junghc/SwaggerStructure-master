import sys
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import csv
import scipy.cluster.hierarchy as shc
import scipy.spatial.distance as ssd

def main():
	str = '/home/user/AP2/SwaggerStructure-master/src/main/resources' #sys.argv[0]
	pd.set_option('display.max_rows', 1000)
	customer_data = pd.read_csv(str+'/1253-Swagger.csv')  # LDA-WordNet-588-Distance
	
	  
	
	id = ["14784-Quick start - Telematics SDK","14786-JIRA 7.6.1","451-Netatmo","3332-PDF Generator API","16837-Gitlab","134-Netatmo","3274-IP geolocation API","21965-The Jira Cloud platform REST API","16142-Traccar","655-DaniWeb Connect API","21967-BigQuery API","338-Foursquare","3603-Noosh API application","21-Foursquare","1049-Spotify Web API","5145-Slack Web API","2142-Avaza API Documentation","14558-Orthanc API","14560-Bitbucket API","14562-Prime ReportStream","3238-Interzoid Get Currency Rate API","361-NPR Authorization Service","44-NPR Authorization Service","8239-Trello","11823-Bitbucket API","11825-StackExchange","3250-Foursquare","3325-JWT Example"]

	# convert the redundant n*n square matrix form into a condensed nC2 array
	data = customer_data.iloc[:,1:].values
	
	print(data)
	print(data.shape)
	distArray = ssd.squareform(data) # distArray[{n choose 2}-{n-i choose 2} + (j-i-1)] is the distance between points i and j
	result = shc.linkage(distArray, method='average') # single, complete, average, weighted, centroid
	dend = shc.dendrogram(result, color_threshold=0.8)

	assignments = shc.fcluster(result, 0.8, 'distance')
	print(len(id))
	cluster_output = pd.DataFrame({'team':id , 'cluster':assignments})

	# 寫入到 csv
	cluster_output.to_csv(str+'/Cluster-Results.csv' , encoding = "utf-8")

if __name__ == "__main__":
    main()
