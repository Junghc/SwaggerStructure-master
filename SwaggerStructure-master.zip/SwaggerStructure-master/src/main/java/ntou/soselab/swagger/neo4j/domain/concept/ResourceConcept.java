package ntou.soselab.swagger.neo4j.domain.concept;

public class ResourceConcept extends Concept{

}
