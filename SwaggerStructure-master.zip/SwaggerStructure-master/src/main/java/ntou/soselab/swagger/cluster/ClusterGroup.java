package ntou.soselab.swagger.cluster;

import java.util.ArrayList;

public class ClusterGroup {
    String group;
    ArrayList<String> word;

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public ArrayList<String> getWord() {
        return word;
    }

    public void setWord(ArrayList<String> word) {
        this.word = word;
    }
}
