package ntou.soselab.swagger;

public class PersonalInformation {
    public final static String GITHUB_ACCOUNT = "";
    public final static String GITHUB_PASSWORD = "";
    public final static String ACCESS_TOKEN = "";
}
