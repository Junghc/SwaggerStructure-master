package ntou.soselab.swagger.neo4j.domain.service;

public class ClusterGroupList extends ConcreteService{

    String groupJson;

    public String getGroupJson() {
        return groupJson;
    }

    public void setGroupJson(String groupJson) {
        this.groupJson = groupJson;
    }
}