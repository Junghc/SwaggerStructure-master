package ntou.soselab.swagger.neo4j.repositories.relationship;

import ntou.soselab.swagger.neo4j.domain.relationship.Own;
import org.springframework.data.neo4j.repository.GraphRepository;

public interface OwnRepository extends GraphRepository<Own> {

}
